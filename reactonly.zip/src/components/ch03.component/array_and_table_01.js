import Bread from './ui/BreadList01';
import Coffee from './ui/CoffeeList01';

function App() {
    // console.log('샘플');

    return (
        <div className="App">
            <Bread />
            <hr />
            <Coffee />
        </div>
    );
}

export default App;