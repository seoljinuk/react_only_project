function App(){
    // console.log('샘플');
    
    return(
        <article>
            <h2>맺음말</h2>
            <p>안녕히 가십시요. 다음에 또 뵙겠습니다.</p>
        </article>        
    );     
}

export default App ;