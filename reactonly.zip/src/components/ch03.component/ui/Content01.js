function App() {
    // console.log('샘플');

    return (
        <nav>
            <ul>
                <li><a href="1.html">프렌치 바게트</a></li>
                <li><a href="2.html">크로아상</a></li>
                <li><a href="3.html">브리오슈</a></li>
                <li><a href="4.html">치아바타</a></li>
            </ul>
        </nav>
    );
}

export default App;