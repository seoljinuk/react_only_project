function App() {
    // console.log('샘플');

    return (
        <header>
            <h1>Forest Coffee</h1>
            <p>어서 오세요. 저희 빵집을 방문해 주셔서 감사합니다.</p>
        </header>
    );
}

export default App;