function App(){
    console.log('함수형 컴포넌트');
    return(
        <div className="App">
            <div>함수형 방식(초간단 JSX 실습)</div>
            <img src="http://localhost:3000/brioche_04_bigsize.png" 
                width="300" height="300" />
            <div>반갑습니다.</div>
        </div>
    );   
}

export default App ;