function App(){
    console.log('샘플');
    
    return(
        <div className="App">
            샘플
        </div>
    );     
}

export default App ;